# 🚀 Быстрый старт: Настройка Stripe

## Что было создано

✅ **Скрипты для настройки:**
- `backend/scripts/setup_stripe.py` - полная настройка и проверка Stripe
- `backend/scripts/check_stripe.py` - быстрая проверка конфигурации

✅ **Документация:**
- `docs/STRIPE_SETUP.md` - подробное руководство по настройке
- `backend/scripts/README.md` - описание скриптов

## Быстрая настройка

### 1. Проверьте текущую конфигурацию

```bash
cd backend
python scripts/check_stripe.py
```

### 2. Если ключи не установлены, запустите полную настройку

```bash
python scripts/setup_stripe.py
```

Скрипт покажет:
- Какие ключи отсутствуют
- Инструкции по их получению
- Как их добавить в `.env` файл

### 3. Добавьте ключи в `.env`

Создайте файл `backend/.env` (если его нет) и добавьте:

```env
STRIPE_SECRET_KEY=sk_test_your_key_here
STRIPE_PUBLISHABLE_KEY=pk_test_your_key_here
STRIPE_WEBHOOK_SECRET=whsec_your_secret_here
```

### 4. Получите ключи из Stripe Dashboard

1. Зарегистрируйтесь на [https://dashboard.stripe.com](https://dashboard.stripe.com)
2. Перейдите в **Developers** → **API keys**
3. Скопируйте ключи в `.env` файл

### 5. Проверьте настройку

```bash
python scripts/setup_stripe.py
```

## Подробная документация

Полное руководство: [docs/STRIPE_SETUP.md](docs/STRIPE_SETUP.md)

## Что дальше?

После настройки Stripe вы сможете:
- ✅ Принимать платежи через Stripe
- ✅ Сохранять способы оплаты
- ✅ Обрабатывать webhook'и
- ✅ Выводить средства

Все функции уже реализованы и протестированы (112/112 тестов пройдено)!

