# Настройка Stripe для LOOSELINE Wallet

Это руководство поможет вам настроить Stripe для работы с модулем кошелька LOOSELINE.

## 📋 Содержание

1. [Создание аккаунта Stripe](#создание-аккаунта-stripe)
2. [Получение API ключей](#получение-api-ключей)
3. [Настройка Webhook](#настройка-webhook)
4. [Конфигурация проекта](#конфигурация-проекта)
5. [Тестирование](#тестирование)
6. [Переход на Production](#переход-на-production)

---

## 🚀 Создание аккаунта Stripe

1. Перейдите на [https://dashboard.stripe.com/register](https://dashboard.stripe.com/register)
2. Зарегистрируйтесь или войдите в существующий аккаунт
3. Заполните информацию о вашем бизнесе
4. Подтвердите email адрес

> **Примечание:** Для начала работы можно использовать тестовый режим (Test Mode), который включён по умолчанию.

---

## 🔑 Получение API ключей

### Шаг 1: Откройте страницу API ключей

1. Войдите в [Stripe Dashboard](https://dashboard.stripe.com)
2. Перейдите в раздел **Developers** → **API keys**
3. Убедитесь, что вы находитесь в **Test mode** (переключатель в правом верхнем углу)

### Шаг 2: Скопируйте ключи

Вы увидите два ключа:

- **Publishable key** (начинается с `pk_test_...`)
  - Используется на фронтенде для создания Payment Intent
  - Безопасно публиковать в клиентском коде

- **Secret key** (начинается с `sk_test_...`)
  - Используется на бэкенде для всех операций
  - **НИКОГДА** не публикуйте этот ключ!

### Шаг 3: Сохраните ключи

Скопируйте оба ключа в безопасное место. Они понадобятся для настройки проекта.

---

## 🔔 Настройка Webhook

Webhook'и позволяют Stripe уведомлять ваше приложение о событиях (успешные платежи, ошибки и т.д.).

### Шаг 1: Создайте Webhook Endpoint

1. Перейдите в **Developers** → **Webhooks**
2. Нажмите **Add endpoint**
3. Заполните форму:
   - **Endpoint URL**: `https://your-domain.com/api/webhooks/stripe`
     - Для локальной разработки используйте [Stripe CLI](https://stripe.com/docs/stripe-cli)
   - **Description**: "LOOSELINE Wallet Webhook"
   - **Events to send**: Выберите следующие события:
     - `payment_intent.succeeded`
     - `payment_intent.payment_failed`
     - `payment_intent.canceled`

4. Нажмите **Add endpoint**

### Шаг 2: Получите Webhook Secret

1. После создания endpoint, откройте его
2. Найдите раздел **Signing secret**
3. Нажмите **Reveal** и скопируйте секрет (начинается с `whsec_...`)

> **Важно:** Webhook secret используется для проверки подлинности запросов от Stripe.

### Шаг 3: Локальная разработка с Stripe CLI

Для локальной разработки используйте Stripe CLI:

```bash
# Установите Stripe CLI
# https://stripe.com/docs/stripe-cli

# Авторизуйтесь
stripe login

# Запустите форвардинг webhook'ов
stripe listen --forward-to localhost:8000/api/webhooks/stripe
```

Stripe CLI покажет webhook secret, который нужно использовать в `.env` файле.

---

## ⚙️ Конфигурация проекта

### Шаг 1: Создайте .env файл

Скопируйте пример конфигурации:

```bash
cp backend/env.example.txt backend/.env
```

### Шаг 2: Добавьте Stripe ключи

Откройте `backend/.env` и добавьте:

```env
# Stripe Configuration
STRIPE_SECRET_KEY=sk_test_your_secret_key_here
STRIPE_PUBLISHABLE_KEY=pk_test_your_publishable_key_here
STRIPE_WEBHOOK_SECRET=whsec_your_webhook_secret_here
```

Замените значения на ваши реальные ключи.

### Шаг 3: Проверьте конфигурацию

Запустите скрипт проверки:

```bash
cd backend
python scripts/setup_stripe.py
```

Скрипт проверит:
- ✅ Наличие всех ключей
- ✅ Формат ключей
- ✅ Подключение к Stripe API
- ✅ Создание тестового клиента
- ✅ Создание Payment Intent

---

## 🧪 Тестирование

### Тестовые карты

Stripe предоставляет тестовые карты для проверки различных сценариев:

| Номер карты | Сценарий |
|------------|----------|
| `4242 4242 4242 4242` | Успешный платёж |
| `4000 0000 0000 0002` | Отклонённый платёж |
| `4000 0025 0000 3155` | Требует 3D Secure |
| `4000 0000 0000 9995` | Недостаточно средств |

**Для всех тестовых карт:**
- **Дата истечения**: Любая будущая дата (например, `12/25`)
- **CVC**: Любые 3 цифры (например, `123`)
- **ZIP**: Любой (например, `12345`)

### Тестирование пополнения баланса

1. Запустите сервер:
   ```bash
   cd backend
   uvicorn main:app --reload
   ```

2. Откройте фронтенд или используйте API:
   ```bash
   curl -X POST http://localhost:8000/api/wallet/replenish \
     -H "Content-Type: application/json" \
     -d '{
       "user_id": "user_123",
       "amount": 100.00
     }'
   ```

3. Используйте тестовую карту `4242 4242 4242 4242` для оплаты

### Тестирование Webhook'ов

#### С Stripe CLI (рекомендуется для локальной разработки):

```bash
# В отдельном терминале
stripe listen --forward-to localhost:8000/api/webhooks/stripe

# Отправьте тестовое событие
stripe trigger payment_intent.succeeded
```

#### Через Dashboard:

1. Перейдите в **Developers** → **Webhooks**
2. Откройте ваш endpoint
3. Нажмите **Send test webhook**
4. Выберите событие `payment_intent.succeeded`
5. Нажмите **Send test webhook**

---

## 🚀 Переход на Production

### Шаг 1: Переключитесь на Live Mode

1. В Stripe Dashboard переключите режим на **Live mode**
2. Получите **Live API keys**:
   - `pk_live_...` (Publishable key)
   - `sk_live_...` (Secret key)

### Шаг 2: Обновите Webhook

1. Создайте новый webhook endpoint для production
2. URL: `https://your-production-domain.com/api/webhooks/stripe`
3. Скопируйте новый webhook secret (`whsec_...`)

### Шаг 3: Обновите .env

```env
# Production Stripe Configuration
STRIPE_SECRET_KEY=sk_live_your_live_secret_key
STRIPE_PUBLISHABLE_KEY=pk_live_your_live_publishable_key
STRIPE_WEBHOOK_SECRET=whsec_your_live_webhook_secret
```

### Шаг 4: Проверьте настройки

1. Убедитесь, что `APP_ENV=production` в `.env`
2. Запустите скрипт проверки:
   ```bash
   python scripts/setup_stripe.py
   ```

### Шаг 5: Включите дополнительные функции

В Stripe Dashboard настройте:
- **Radar** - защита от мошенничества
- **3D Secure** - дополнительная аутентификация
- **Email уведомления** - о важных событиях
- **Логирование** - для отладки

---

## 🔒 Безопасность

### ✅ Рекомендации:

1. **Никогда не коммитьте `.env` файл** в Git
2. Используйте **разные ключи** для test и production
3. Регулярно **ротируйте ключи** (особенно в production)
4. Используйте **HTTPS** для всех webhook endpoints
5. Проверяйте **webhook signature** (уже реализовано в коде)
6. Храните ключи в **безопасном месте** (например, AWS Secrets Manager)

### ❌ Что НЕ делать:

- ❌ Не публикуйте Secret keys в клиентском коде
- ❌ Не используйте production ключи в тестах
- ❌ Не игнорируйте webhook signature проверки
- ❌ Не логируйте полные данные карт

---

## 📚 Дополнительные ресурсы

- [Stripe Documentation](https://stripe.com/docs)
- [Stripe API Reference](https://stripe.com/docs/api)
- [Stripe Testing](https://stripe.com/docs/testing)
- [Stripe Webhooks Guide](https://stripe.com/docs/webhooks)
- [Stripe CLI](https://stripe.com/docs/stripe-cli)

---

## 🆘 Решение проблем

### Проблема: "Invalid API Key"

**Решение:**
- Проверьте, что ключ скопирован полностью (без пробелов)
- Убедитесь, что используете правильный режим (test/live)
- Проверьте формат ключа (должен начинаться с `sk_test_` или `sk_live_`)

### Проблема: Webhook не работает

**Решение:**
- Проверьте, что webhook endpoint доступен из интернета
- Убедитесь, что используете правильный webhook secret
- Проверьте логи сервера на наличие ошибок
- Используйте Stripe CLI для локальной разработки

### Проблема: Платежи отклоняются

**Решение:**
- Используйте тестовые карты из таблицы выше
- Проверьте, что сумма больше минимальной (1.00 USD)
- Убедитесь, что валюта указана как "usd"
- Проверьте логи Stripe Dashboard на наличие ошибок

---

## ✅ Чеклист настройки

- [ ] Создан аккаунт Stripe
- [ ] Получены Test API keys
- [ ] Настроен Webhook endpoint
- [ ] Получен Webhook secret
- [ ] Добавлены ключи в `.env` файл
- [ ] Запущен скрипт проверки (`setup_stripe.py`)
- [ ] Протестировано пополнение баланса
- [ ] Протестированы webhook'и
- [ ] (Для production) Получены Live API keys
- [ ] (Для production) Настроен production webhook

---

**Готово!** 🎉 Теперь Stripe полностью настроен и готов к работе.

